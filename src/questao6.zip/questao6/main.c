/**
 * Edwino Stein - 120132441
 */
 
#include <at89x52.h>

#define PAINEL_LED			P2
#define LED_READY 			P2_0
#define LED_COIN 				P2_1
#define LED_COFFE 			P2_2
#define LED_TEE 				P2_3

#define DRINK_SWITCH 		P3_0
#define COIN_DROPPER		P3_2
#define BUTTON					P3_3

#define MAX_SERVING_TIME 10

const LIGAR = 1;
const DESLIGAR = 0;

bit hasCoin;
int timerConter;
int servingTimer;

/**
 * Callback para interru��o gerada pela inser��o da moeda
 */
void onCoinInserted() interrupt 0 {
	LED_COIN = LIGAR;
	hasCoin = LIGAR;
	COIN_DROPPER = LIGAR;
}

/**
 * Callback para interru��o de tempo
 */
void onTimerOverflow() interrupt 1 {
	
	TR0 = DESLIGAR;
	TH0 = 0x0;
	TL0 = 0x0;
	TR0 = LIGAR;
	timerConter++;
	
	if(timerConter == 25){
		timerConter = 0;
		servingTimer++;
		LED_READY = ~LED_READY;
	}
}

/**
 * Reinia a maquina para seu estado inicial
 */
void reset(){
	TR0 = DESLIGAR;
	PAINEL_LED = DESLIGAR;
	LED_READY = LIGAR;
	
	hasCoin = DESLIGAR;
	COIN_DROPPER = LIGAR;
	BUTTON = DESLIGAR;
}

/**
 * Fun��o que realiza a opera��o de servir a bebida selecionada
 */
void serving(bit drink){
	
	TH0 = 0x0;							//
	TL0 = 0x0;							//
	TR0 = LIGAR;						// Inicializa o timer
	timerConter = 0;				//
	servingTimer = 0;				//
	
	LED_READY = DESLIGAR;
	while(servingTimer < MAX_SERVING_TIME){	
		
		LED_COFFE = drink;											//
		LED_TEE = ~drink;												// Mantem o estado dos LEDS e bot�es
		DRINK_SWITCH = drink;										// enquanto a a bebida � servida
		COIN_DROPPER = LIGAR;										//  
		BUTTON = DESLIGAR;											//
		
		//Servindo a bebida...
	}
	
	// Reinia a maquina quanto terminar de servir
	reset();
}

/**
 * Callback para quando o bot�o for pressionado
 */
void onBtnPressed(){
	if(hasCoin) serving(DRINK_SWITCH);
	BUTTON = DESLIGAR;
}

/**
 * Programa princial
 */
void main(){
	
	EA = LIGAR;				//
	EX0 = LIGAR;			// Inicializa as interrup�oes
	ET0 = LIGAR;			//
	TMOD = 0x1;				//
	
	reset();
	while(1){
		
		// Aguardando o bot�o ser pressionado
		if(BUTTON) onBtnPressed();
		
		// Comportamento do switch de bebidas
		LED_COFFE = DRINK_SWITCH;
		LED_TEE = ~DRINK_SWITCH;
	}
}