/**
 * Edwino Stein - 1201324411
 */

#include <at89x52.h>

#define BOX_MAX_SIZE 			5
#define BOX_TRACK_LED 		P2_0
#define PRODUCT_TRACK_LED P2_1

bit BOX_TRACK_ACTIVED;
bit PRODUCT_TRACK_ACTIVED;

const LIGAR = 1;
const DESLIGAR = 0;

/**
 * Define o estado da esteira de caixas
 */
void setStateBoxTrack(bit state){
	BOX_TRACK_ACTIVED = state;
	BOX_TRACK_LED = state;
}

/**
 * Define o estado da esteira de produtos
 */
void setStateProductTrack(bit state){
	PRODUCT_TRACK_ACTIVED = state;
	PRODUCT_TRACK_LED = state;
}

/**
 * Define o valor de estouro do contador
 */
void resetCounter(int maxCount){
	TH0 = 0xFF;										// Define o n�mero de itens para o estouro:
	TL0 = (0xFF - maxCount) + 1;	// (65535 - maxCount) + 1
}

/**
 * Callback para o estouro do contador
 */
void onCounterOverflow() interrupt 1 {
	if(BOX_TRACK_ACTIVED){					
		setStateBoxTrack(DESLIGAR);			// Desativa a esteira das caixas,
		setStateProductTrack(LIGAR);		// ativa a esteira dos produtos 
		resetCounter(BOX_MAX_SIZE);			// e reseta o contador pra N produtos
	}
	else if(PRODUCT_TRACK_ACTIVED){
		setStateBoxTrack(LIGAR);				// Ativa a esteira das caixas,
		setStateProductTrack(DESLIGAR);	// Desativa a esteira dos produtos
		resetCounter(1);								// e reseta o contador para 1 caixa
	}
}

void main(){
	EA = LIGAR;		// Habilita as interrup��es
	ET0 = LIGAR;	// Habilita interrup��o Timer0
	TMOD = 0x05;	// Habilita o modo contador de sinal recebido pela porta 3.4
	TR0 = LIGAR;	// Habilita o Timer no modo "roda"
	
	P2 = DESLIGAR;
	setStateBoxTrack(LIGAR);
	setStateProductTrack(DESLIGAR);
	resetCounter(1);
	
	while(1);			// Fazendo outras coisas...
}